#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include <sstream>
#include <map>

using namespace std;

struct RichMan{
  string name;
  float rank;
  int age;
  string country;
  int finalWorth;
};


int main(int argc,char *argv[]){
  string path = argv[1];
  string countryInput = argv[2];
  int ageInput = stoi(argv[3]);
  fstream file(path);
  // ostream outfile("/home/vuthoai/codeC/C-NangCao/kiemtra/result.csv",ios_base::app);
  if(!file){
    cout << "Khong doc duoc file!";
    exit(0);
  }
  vector<RichMan> richMan;
  map<string:int> country;
  string temp;
  getline(file,temp);
  int smAge=0;
  int count = 0;
  while(getline(file,temp)){
    richMan.push_back(RichMan());
    stringstream ss(temp);
    string token;
    getline(ss,token,',');
    int rank = std::stof(token);
    richMan[rank].rank = rank;
    getline(ss,token,',');
    richMan[rank].name = token;
    getline(ss,token,',');
    richMan[rank].age = stoi(token);
    getline(ss,token,',');
    richMan[rank].finalWorth = stoi(token);
    getline(ss,token,',');
    getline(ss,token,',');
    getline(ss,token,',');
    getline(ss,token,',');
    getline(ss,token,',');
    richMan[rank].country = token;
    if(richMan[rank].country == countryInput){
      outfile<<richMan[rank].rank<<","<<richMan[rank].name<<","<<richMan[rank].age<<","<<richMan[rank].finalWorth<<","<<richMan[rank].finalWorth<<endl;
    }
    if(richMan[rank].age < ageInput) smAge++;
    count++;
  }
  cout<< "So ty phu co tuoi nho hon " << ageInput<< " chiem "<<(smAge/count)*100<<"%\n";
  return 0;
}
