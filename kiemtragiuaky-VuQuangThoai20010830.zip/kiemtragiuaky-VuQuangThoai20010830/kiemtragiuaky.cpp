#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <vector>

using namespace std;

struct Tip{
  string id;
  float total_bill;
  float tip;
  string sex, smoke,day,time;
  int size;
};

int main(int argc, char* argv[]){
  string path = argv[1];
  fstream file(path);
  if(!file){
    cout<< "Error read file!";
    exit(0);
  }
  vector<Tip> khach;
  string temp;
  getline(file,temp);
  float totalTip = 0;
  float all = 0;
  int id = 0;
  float maleTip = 0;
  float femaleTip = 0;
  while (getline(file,temp))
  {
    khach.push_back(Tip());
    stringstream ss(temp);
    string token;
    getline(ss,token,',');
    getline(ss,token,',');
    khach[id].total_bill = stof(token);
    getline(ss,token,',');
    khach[id].tip = stof(token);
    getline(ss,token,',');
    khach[id].sex = token;
    getline(ss,token,',');
    khach[id].smoke = token;
    getline(ss,token,',');
    khach[id].day = token;
    getline(ss,token,',');
    khach[id].time = token;
    getline(ss,token,',');
    khach[id].size = stoi(token);
    totalTip+=khach[id].tip;
    all += khach[id].total_bill+khach[id].tip;
    if(khach[id].sex == "Male"){
      maleTip+=khach[id].tip;
    }else femaleTip+=khach[id].tip;
    id++;

  }
  cout << "total tip: " << totalTip << " all: " << all<<endl;
  cout << "Tien tip chiem : " << (totalTip/all)*100 << "% tong so tien!\n";
  float avdMaleTip = (maleTip/all)*100;
  float avdFemaleTip = (femaleTip/all)*100;
  cout << "Tien tip cua nam chiem : " <<avdMaleTip<<"% va nu chiem: "<<avdFemaleTip<<"%"<<endl;
  if(avdMaleTip > avdFemaleTip) cout << "Nam tip nhieu hon nu!\n";
  else cout<<"Nu tip nhieu hon nam!\n";


  return 0;
}